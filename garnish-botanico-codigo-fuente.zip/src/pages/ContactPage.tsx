import { useState } from 'react';
import SEOHead from '../components/SEOHead';
import Breadcrumbs from '../components/Breadcrumbs';
import { validateContactForm } from '../utils/rules';
import { Mail, Send, CheckCircle2, AlertCircle, Clock, Shield } from 'lucide-react';

interface ContactPageProps {
  onNavigate: (path: string) => void;
}

export default function ContactPage({ onNavigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    consent: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
    if (errors[name]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateContactForm(formData);

    if (!result.valid) {
      setErrors(result.errors);
      return;
    }

    // Proceso de envío exitoso simulado en cliente
    setSubmitted(true);
    setErrors({});
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
      consent: false,
    });
    setSubmitted(false);
  };

  return (
    <>
      <SEOHead
        title="Contacto editorial"
        description="Ponte en contacto con el equipo editorial de Garnish Botánico para consultas técnicas, correcciones botánicas o colaboraciones."
        pathname="/contacto"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        <Breadcrumbs
          items={[{ label: 'Contacto' }]}
          onNavigate={onNavigate}
        />

        <header className="space-y-4 border-b border-stone-200 pb-8">
          <span className="text-xs font-mono uppercase tracking-widest text-[#7A9A85]">
            Comunicación y Consultas
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-medium tracking-tight text-[#142E22]">
            Contacto editorial
          </h1>
          <p className="text-base sm:text-lg text-stone-700 leading-relaxed font-sans">
            ¿Tienes alguna duda sobre la identificación botánica de una flor, una propuesta técnica o deseas notificarnos una fe de erratas? Escríbenos directamente.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Información de Contacto Directo */}
          <div className="md:col-span-5 space-y-6">
            <div className="bg-[#FAF7F0] border border-stone-300 rounded-xl p-6 space-y-4">
              <h3 className="font-serif font-bold text-lg text-[#142E22]">
                Datos oficiales
              </h3>
              
              <div className="space-y-3 text-xs sm:text-sm text-stone-700 font-sans">
                <div>
                  <span className="font-semibold block text-stone-900">Responsable editorial:</span>
                  <span>Andres Martinez</span>
                </div>

                <div>
                  <span className="font-semibold block text-stone-900">Correo electrónico oficial:</span>
                  <a
                    href="mailto:andresy1999@gmail.com"
                    className="text-[#142E22] underline font-medium hover:text-[#1B382B]"
                  >
                    andresy1999@gmail.com
                  </a>
                </div>

                <div>
                  <span className="font-semibold block text-stone-900">Plataforma y dominio:</span>
                  <span className="font-mono text-xs">https://tecnoteke.lol/</span>
                </div>
              </div>

              <div className="pt-3 border-t border-stone-200 text-xs text-stone-600 space-y-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#7A9A85]" />
                  <span>Plazo de respuesta estimado: 24 a 48 horas hábiles.</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#7A9A85]" />
                  <span>Tus datos solo se usan para responder tu consulta.</span>
                </div>
              </div>
            </div>

            <div className="p-5 bg-white border border-stone-200 rounded-xl text-xs text-stone-600 space-y-2">
              <h4 className="font-serif font-bold text-stone-900 text-sm">
                Aviso importante sobre consultas médicas
              </h4>
              <p className="leading-relaxed">
                Garnish Botánico no presta asesoramiento médico ni atiende casos de intoxicación aguda. En caso de sospecha de intoxicación vegetal, acude a los servicios de urgencia médica o contacta con el centro de toxicología de tu país.
              </p>
            </div>
          </div>

          {/* Formulario de Contacto Funcional */}
          <div className="md:col-span-7">
            {submitted ? (
              <div className="bg-[#F4F9F5] border border-[#CDE5D4] rounded-2xl p-8 text-center space-y-4 animate-in fade-in duration-300">
                <div className="w-12 h-12 rounded-full bg-[#142E22] text-white flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-serif font-bold text-2xl text-[#142E22]">
                  ¡Mensaje enviado con éxito!
                </h3>
                <p className="text-sm text-stone-700 leading-relaxed max-w-md mx-auto">
                  Gracias por ponerte en contacto con Garnish Botánico. Andres Martinez revisará tu mensaje a la mayor brevedad posible en la dirección indicada ({formData.email}).
                </p>
                <div className="pt-4">
                  <button
                    onClick={handleReset}
                    className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#142E22] bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors"
                  >
                    Enviar otra consulta
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 space-y-5 shadow-xs">
                
                {/* Nombre */}
                <div className="space-y-1.5">
                  <label htmlFor="name" className="block text-xs font-semibold uppercase tracking-wider text-stone-800">
                    Nombre completo <span className="text-[#7D2D3B]">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Ej. María González"
                    className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-[#FAF7F0]/40 text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#142E22] ${
                      errors.name ? 'border-[#7D2D3B]' : 'border-stone-300'
                    }`}
                  />
                  {errors.name && (
                    <p className="text-xs text-[#7D2D3B] flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.name}</span>
                    </p>
                  )}
                </div>

                {/* Email */}
                <div className="space-y-1.5">
                  <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wider text-stone-800">
                    Correo electrónico <span className="text-[#7D2D3B]">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="tuemail@ejemplo.com"
                    className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-[#FAF7F0]/40 text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#142E22] ${
                      errors.email ? 'border-[#7D2D3B]' : 'border-stone-300'
                    }`}
                  />
                  {errors.email && (
                    <p className="text-xs text-[#7D2D3B] flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>

                {/* Asunto */}
                <div className="space-y-1.5">
                  <label htmlFor="subject" className="block text-xs font-semibold uppercase tracking-wider text-stone-800">
                    Motivo o Asunto <span className="text-[#7D2D3B]">*</span>
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-[#FAF7F0]/40 text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#142E22] ${
                      errors.subject ? 'border-[#7D2D3B]' : 'border-stone-300'
                    }`}
                  >
                    <option value="">Selecciona un motivo...</option>
                    <option value="Consulta sobre cultivo">Consulta sobre cultivo agronómico</option>
                    <option value="Identificación y seguridad">Identificación botánica o seguridad alimentaria</option>
                    <option value="Coctelería y gastronomía">Aplicación en coctelería o alta cocina</option>
                    <option value="Corrección o fe de erratas">Corrección editorial o fe de erratas</option>
                    <option value="Otro">Otro asunto editorial</option>
                  </select>
                  {errors.subject && (
                    <p className="text-xs text-[#7D2D3B] flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.subject}</span>
                    </p>
                  )}
                </div>

                {/* Mensaje */}
                <div className="space-y-1.5">
                  <label htmlFor="message" className="block text-xs font-semibold uppercase tracking-wider text-stone-800">
                    Mensaje detallado <span className="text-[#7D2D3B]">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Escribe tu consulta con la mayor precisión posible..."
                    className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-[#FAF7F0]/40 text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#142E22] ${
                      errors.message ? 'border-[#7D2D3B]' : 'border-stone-300'
                    }`}
                  />
                  {errors.message && (
                    <p className="text-xs text-[#7D2D3B] flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                {/* Consentimiento */}
                <div className="space-y-1.5 pt-1">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      id="consent"
                      name="consent"
                      checked={formData.consent}
                      onChange={handleChange}
                      className="mt-1 w-4 h-4 rounded text-[#142E22] focus:ring-[#142E22] border-stone-300"
                    />
                    <span className="text-xs text-stone-600 leading-snug">
                      He leído y acepto la{' '}
                      <button
                        type="button"
                        onClick={() => onNavigate('/politica-de-privacidad')}
                        className="text-[#142E22] underline font-medium hover:text-[#1B382B]"
                      >
                        política de privacidad
                      </button>{' '}
                      para la gestión y respuesta de esta consulta. <span className="text-[#7D2D3B]">*</span>
                    </span>
                  </label>
                  {errors.consent && (
                    <p className="text-xs text-[#7D2D3B] flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{errors.consent}</span>
                    </p>
                  )}
                </div>

                {/* Botón de Envío */}
                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#142E22] rounded-lg hover:bg-[#1B382B] active:scale-98 transition-all duration-150 shadow-sm"
                  >
                    <Send className="w-4 h-4" />
                    <span>Enviar consulta editorial</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
